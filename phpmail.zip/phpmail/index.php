<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
<table>
    <form method="post" action="mail2.php">
        <tr>
            <td>Email</td>
            <td><input type="text" name="email"></td>
        </tr>
        <tr>
            <td><input type="submit" name="s" value="send"></td>
        </tr>
    </form>
</table>
</body>
</html>